// así selecciono una etiqueta del html
//let titulo = document.querySelector('h1');

//con esta llamada a la variable se define un título
//titulo.innerHTML = 'Juego del número secreto'

//let parrafo = document.querySelector('p');
//parrafo.innerHTML = 'Indica un número del 1 al 10';

let numeroSecreto = 0;

let intentos = 0;

let listasNumerosSorteados = [];

let numeroMaximo = 10;

//console.log(numeroSecreto);

//crear una función para no repetir código como el de arriba, utilizando parámetros
function asignarTextoElemento (elemento, texto) {
    let elementoHTML = document.querySelector(elemento);
    elementoHTML.innerHTML = texto;
    return; //no retorna nada, pero es un buena práctica
}

//funciones
function verificarIntento() {
    let numeroDeUsuario = parseInt(document.getElementById('valorUsuario').value);
    //console.log(typeof(numeroDeUsuario));
    //console.log(typeof(numeroSecreto));
    //console.log(numeroDeUsuario);

    //console.log(intentos);

    //console.log(numeroDeUsuario === numeroSecreto);
    if (numeroDeUsuario === numeroSecreto) {
        //para mostrar veces o vez se usa operador ternario
        asignarTextoElemento('p', `Acertaste el número en ${intentos} ${(intentos === 1) ? 'vez.' : 'veces.'}`); 
        document.getElementById('reiniciar').removeAttribute('disabled');
    } else { 
        //El usuario no acertó
        if (numeroDeUsuario > numeroSecreto) {
            asignarTextoElemento('p', 'El número secreto es menor');
        } else {
            asignarTextoElemento('p', 'El número secreto es mayor');
        }
        intentos++;
        limpiarCaja();
    }
    return;
}

function limpiarCaja() {
    //se puede con queryselector con ID, por eso es el #
    // se puede optimizar haciendo    document.querySelector('#valorUsuario').value = '';
    let valorCaja = document.querySelector('#valorUsuario');
    valorCaja.value = '';
}

//Función para generar número aleatorio
function generarNumeroSecreto () {
    let numeroGenerado = Math.floor(Math.random()*numeroMaximo)+1; // en una función no necesito crear variable para retornar, se puede directamente.
    //Si el número generado está incluido en la lista hacemos algo si no hacemos otra 
    
    console.log(numeroGenerado);
    console.log(listasNumerosSorteados);
    // Si ya sorteamos todos los números
    if (listasNumerosSorteados.length == numeroMaximo) {
        asignarTextoElemento('p', 'Ya se sortearon todos los números posibles.');
    } else {
        //Si el número generado está incluido en la lista
        if (listasNumerosSorteados.includes(numeroGenerado)) {
            return generarNumeroSecreto();
        } else {
            listasNumerosSorteados.push(numeroGenerado);
            return numeroGenerado;
        }
    }

    

}

function condicionesIniciales() {
    asignarTextoElemento('h1', 'Juego del número secreto');
    asignarTextoElemento('p', `Indica un número del 1 al ${numeroMaximo}`);
    numeroSecreto = generarNumeroSecreto();
    intentos = 1;
}


function reiniciarJuego() {
    //limpiar caja
    limpiarCaja();
    //indicar mensaje de intervalo de números
    condicionesIniciales();
    //Generar el número aleatorio      //Inicializar el número intentos
    //condicionesIniciales();
    //Deshabilitar el botón de nuevo juego
    document.querySelector('#reiniciar').setAttribute('disabled', 'true');
}


condicionesIniciales();




